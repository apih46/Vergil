<!DOCTYPE html>
<h2 align="center">
⏩ AUTOSCRIPT SSH / XRAY WEBSOCKET MULTIPORT 443 DETAILS ⏪

  By apih46 
<br> 
  
<h2 align="center"> ♦️Supported Linux Distribution♦️</h2>
<p align="center"><img src="https://d33wubrfki0l68.cloudfront.net/5911c43be3b1da526ed609e9c55783d9d0f6b066/9858b/assets/img/debian-ubuntu-hover.png"width="400"></p>
<p align="center"><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%2010&message=Buster&color=red"> <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=ubuntu&label=Ubuntu%2020.04&message=LTS&color=orange"></p>
  
<p align="center"><img src="https://img.shields.io/badge/Service-Multiport (XRAYS)-white"></p>

## ⚠️ PLEASE README ⚠️
1. Your SSL/TLS encryption mode is Full
2. Enable SSL/TLS Recommender ✅
3. Edge Certificates > Disable Always Use HTTPS (off)

## Tested
1. Ubuntu 20.04,Debian 10
2. Minimum 1GB RAM TO USE THIS SCRIPT
3. Tested from VPS DigitalOcean, Centerhop, Melbicom

## Register IP ( PM username & IP-VPS ) : <a href="https://t.me/todfix667" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a><br>

<br>
</b>
</b>

♦️ For Debian 10 Only For First Time Installation (Update Repo) <br>
 
  ```html
 apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot
  ```
  ♦️ For Ubuntu 20.04 Only For First Time Installation (Update Repo) <br>
  
  ```html
 apt-get update && apt-get upgrade -y && apt dist-upgrade -y && update-grub && reboot
 ```
♦️ Installation Link  <br>

  ```html
sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update && apt install -y bzip2 gzip coreutils screen curl unzip && wget https://raw.githubusercontent.com/apih46/Vergil/main/setup.sh && chmod +x setup.sh && sed -i -e 's/\r$//' setup.sh && screen -S setup ./setup.sh
  ```
<b>

## ⏩ XRAY MULTIPORT WEBSOCKET AUTOSCRIPT DETAILS ⏪
<b>
[ XRAY SERVICES ] <br>
<br>
♦️ XRAY VMESS WEBSOCKET 443/80<br>
♦️ XRAY VLESS WEBSOCKET 443/80 <br>
♦️ XRAY TROJAN WEBSOCKET 443/80<br>
♦️ XRAY VMESS GRPC 443<br>
♦️ XRAY VLESS GRPC 443  <br>
♦️ XRAY TROJAN GRPC 443<br>
♦️ SSH WEBSOCKET 443/80<br>
♦️ SSH SLOWDNS 443/53/5300<br>
♦️ SSH UDP 1-65535<br>
<br>
[ OTHER SERVICES ] <br>
<br>

♦️ USING LATEST XRAY CORE <br>
♦️ NEW UPDATE BBRPLUS 5.15.96 <br>
♦️ BANDWITH MONITOR <br>
♦️ RAM & CPU MONITOR <br>
♦️ DNS CHANGER <br>
♦️ NETFLIX REGION CHECKER <br>
♦️ CHECK LOGIN USER <br>
♦️ CHECK CREATED CONFIG <br>
♦️ AUTOMATIC CLEAR LOG <br>
♦️ AUTOMATIC VPS AUTOREBOOT 07.00 GMT+8 <br>
♦️ AUTOMATIC DELETE EXPIRED ACCOUNT <br>
♦️ BACKUP & RESTORE <br></br>
